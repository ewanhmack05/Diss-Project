# React Colour Palette

A lightweight colour picker for React, inspired by `react-color-palette`, with a focus on predictable behaviour, simple styling, and easy integration into existing applications.

This package provides:
- A saturation/value picker
- A hue slider
- Hex and RGB input fields
- A small, controlled API surface

The picker is fully controlled via props and works well inside tool panels and modals.

![Recording2026-01-26212119-ezgif com-video-to-gif-converter](https://github.com/user-attachments/assets/b9729a2d-8b82-44c8-a612-d32a1918534f)

---

## Local Development and Packaging

### Install dependencies

From the repository root:

```bash
npm install
```

---

### Build the package

Builds the library into the `dist/` folder:

```bash
npm run build
```

---

### Create a tarball

Generates a packaged `.tgz` file that can be installed locally:

```bash
npm pack
```

This will create a file similar to:

```text
react-colour-palette-0.0.1.tgz
```

---

### Use the tarball in another React app

From your React application root:

```bash
npm install /path/to/react-colour-palette-0.0.1.tgz
```

Example:

```bash
npm install C:/Users/yourname/Desktop/ColorPicker/react-colour-palette-0.0.1.tgz
```

---

### Import and use

```tsx
import { ColorPicker, useColor } from 'react-colour-palette';
import 'react-colour-palette/dist/index.css';
```

After reinstalling the tarball, restart the development server to ensure changes are picked up.

## Basic Usage

```tsx
import { ColorPicker, useColor } from 'react-colour-palette';
import 'react-colour-palette/dist/index.css';

function Example() {
  const [color, setColor] = useColor('hex', '#808080');

  return (
    <ColorPicker
      color={color}
      onChange={setColor}
      onChangeComplete={setColor}
      dark
    />
  );
}
```

---

## useColor

```ts
useColor(model, initialValue)
```

Creates and manages a colour state object.

### Parameters

- `model`: `'hex' | 'rgb' | 'hsv'`
- `initialValue`: string (hex colour)

### Returns

```ts
[Color, (nextColor: Color) => void]
```

---

## ColorPicker Props

### Required

| Prop | Type | Description |
|-----|------|-------------|
| `color` | `Color` | Current colour value |
| `onChange` | `(color: Color) => void` | Called while the user is interacting |

### Optional

| Prop | Type | Description |
|-----|------|-------------|
| `onChangeComplete` | `(color: Color) => void` | Called when interaction finishes |
| `width` | `number` | Width of the picker |
| `height` | `number` | Height of the saturation area |
| `dark` | `boolean` | Enables dark theme styling |
| `hideHEX` | `boolean` | Hides the hex input |
| `hideRGB` | `boolean` | Hides the RGB inputs |
| `hideHSV` | `boolean` | Reserved for future use |
| `alpha` | `boolean` | Reserved for future use |

---

## Color Object

```ts
interface Color {
  hex: string;
  rgb: {
    r: number;
    g: number;
    b: number;
    a: number;
  };
  hsv: {
    h: number;
    s: number;
    v: number;
    a: number;
  };
}
```

---

## Styling

The picker ships with a default stylesheet:

```ts
import 'react-colour-palette/dist/index.css';
```

All styles are applied via class names prefixed with `rcp-` and can be overridden if needed.
